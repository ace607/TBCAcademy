//
//  colorCollectionViewCell.swift
//  color-grid
//
//  Created by Admin on 5/18/20.
//  Copyright © 2020 Mishka TBC. All rights reserved.
//

import UIKit

class colorCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var colorCodeLabel: UILabel!
    @IBOutlet weak var colorNameLabel: UILabel!
    
}
