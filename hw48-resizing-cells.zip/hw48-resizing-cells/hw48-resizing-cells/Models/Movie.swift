//
//  Movie.swift
//  hw48-resizing-cells
//
//  Created by Admin on 6/29/20.
//  Copyright © 2020 Mishka TBC. All rights reserved.
//

import UIKit

struct Movie {
    var poster: UIImage
    var title: String
    var desc: String
}
